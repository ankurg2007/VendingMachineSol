﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachineApp
{
   public enum Coins { nickel,dime,quarter,pennie};
  public enum Products { cola,chips,candy }

    public class VendingMachine
    {
        IDictionary<string, double> products = new Dictionary<string, double>();
        public bool productPuchased = false;
        public VendingMachine()
        {
             products = new Dictionary<string, double>(){
    {"cola", 1.00 },
    {"chips", 0.50 },
    {"candy", .65}
         };
        }
        public double Amount = 0.00;

        public void DisplayAmount()
        {
            Console.WriteLine("You have insterted $ " + Amount);
        }
        public void InsertCoins(Coins coin)
        {
            if (coin == Coins.dime)
            {
                Amount = Amount + .10;
            }
            if (coin == Coins.nickel)
            {
                Amount = Amount + .20;
            }
            if (coin == Coins.quarter)
            {
                Amount = Amount + .25;
            }
            if (coin == Coins.pennie)
            {
                Amount = Amount + .001;
            }
            if(coin != Coins.dime && coin != Coins.nickel && coin != Coins.pennie && coin != Coins.quarter )  {
                Console.WriteLine("Invalid Coin Inserted. Please collect your coin");
            }
            DisplayAmount();
        }
        public void SelectProduct(Products selectedProduct)
        {
            if (Products.cola == selectedProduct)
            {
                if (Amount >= products["cola"])
                {
                    Amount = Amount - products["cola"];
                    Console.WriteLine("Thank You Cola Purchased");
                    productPuchased = true;
                }
                else {
                    Console.WriteLine("Price of cola is $1");
                    Console.WriteLine("Please insert $1 for Cola");
                }
            }
            if (Products.chips == selectedProduct)
            {
                if (Amount >= products["chips"])
                {
                    Amount = Amount - products["chips"];
                    Console.WriteLine("Thank You Chips Purchased");
                        productPuchased = true;
                }
                else
                {
                    Console.WriteLine("Price of chips is $.50");
                    Console.WriteLine("Please insert 50 cents for Chips");
                }

            }
                if (Products.candy == selectedProduct)
                {
                if (Amount >= products["candy"])
                {
                    Amount = Amount - products["cola"];
                    Console.WriteLine("Thank You Candy Purchased");
                    productPuchased = true;
                }
                else
                {
                    Console.WriteLine("Price of candy is $.65");
                    Console.WriteLine("Please insert 65 cents for candy");
                }

            }

        }
        }
    class Program
    {
        static void Main(string[] args)
        {
            VendingMachine vm = new VendingMachine();
            beginloop: Console.WriteLine("Please Insert Coins, Curent Amout is " + vm.Amount);
            var coinvalue = Console.ReadLine().ToString().ToLower();
            if ((coinvalue != "dime" && coinvalue != "nickel" && coinvalue != "pennie" && coinvalue!= "quarter"))
            {
                Console.WriteLine("Invalid Coin Inserted. Please collect your coin");
                goto beginloop;
            }
            Coins coin = (Coins)Enum.Parse(typeof(Coins), coinvalue);
            vm.InsertCoins(coin);
            Console.WriteLine("Select Product");
            var selectedproduct = Console.ReadLine().ToString().ToLower();
            Products selectedProduct = (Products)Enum.Parse(typeof(Products), selectedproduct);
            vm.SelectProduct(selectedProduct);
            if (!vm.productPuchased)
            {
                goto beginloop;
            }
            Console.ReadLine();
        }
    }
}
